"""
main.py
------------------------------------------------------------
แสดงสไลด์ "เศษส่วน อัตราส่วน ร้อยละ" (ไฟล์ slides.html ต้นฉบับ)
ผ่าน Streamlit แบบเป๊ะๆ 100% — ไม่มีการแก้ไข HTML/CSS/JS ใดๆ ทั้งสิ้น
โดยใช้วิธี "ฝัง" (embed) ไฟล์ HTML เดิมทั้งไฟล์ลงใน iframe ผ่าน
streamlit.components.v1.html ซึ่งจะรัน CSS animation, JavaScript
(ปุ่ม Next/Prev, Sidebar, Quiz แบบคลิกเฉลย, กราฟ SVG ฯลฯ) ได้ครบทุกฟังก์ชัน
เหมือนเปิดไฟล์ .html ตรงๆ ในเบราว์เซอร์ทุกประการ

วิธีใช้:
1. วางไฟล์นี้ (main.py) และไฟล์ slides.html ไว้ในโฟลเดอร์เดียวกัน
2. รันคำสั่ง: streamlit run main.py
------------------------------------------------------------
"""

import streamlit as st
import streamlit.components.v1 as components
from pathlib import Path

# ---------- ตั้งค่าหน้าเพจให้เต็มจอ ไม่มีขอบ ----------
st.set_page_config(
    page_title="เศษส่วน อัตราส่วน ร้อยละ",
    page_icon="📐",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ---------- ซ่อน UI เริ่มต้นของ Streamlit (เมนู/header/footer/padding) ----------
# เพื่อให้สไลด์ที่ฝังเข้ามาดูเต็มจอเหมือนเปิดไฟล์ HTML ตรงๆ ไม่มีกรอบ Streamlit มาบัง
HIDE_STREAMLIT_CHROME = """
    <style>
        #MainMenu {visibility: hidden;}
        header {visibility: hidden;}
        footer {visibility: hidden;}

        .block-container {
            padding: 0 !important;
            margin: 0 !important;
            max-width: 100% !important;
        }

        /* ทำให้ iframe ของสไลด์ยืดเต็มความสูงหน้าจอพอดี */
        iframe {
            height: 100vh !important;
            width: 100% !important;
            border: none !important;
        }

        .stApp {
            margin: 0 !important;
            padding: 0 !important;
        }
    </style>
"""
st.markdown(HIDE_STREAMLIT_CHROME, unsafe_allow_html=True)

# ---------- อ่านไฟล์ slides.html ต้นฉบับแบบเป๊ะๆ (ไม่แก้ไขเนื้อหาแม้แต่ตัวอักษรเดียว) ----------
SLIDE_FILE = Path(__file__).parent / "slides.html"

if not SLIDE_FILE.exists():
    st.error(
        f"❌ ไม่พบไฟล์ '{SLIDE_FILE.name}' กรุณาวางไฟล์ slides.html "
        f"ไว้โฟลเดอร์เดียวกับ main.py แล้วรันใหม่อีกครั้ง"
    )
else:
    html_content = SLIDE_FILE.read_text(encoding="utf-8")

    # ---------- ฝังสไลด์ HTML ต้นฉบับทั้งไฟล์ลงใน Streamlit แบบเต็มจอ ----------
    # scrolling=False เพราะตัวสไลด์ต้นฉบับออกแบบให้ #deck เป็น position:fixed
    # เต็มพื้นที่ viewport อยู่แล้ว (เหมือนพรีเซนต์เทชันเต็มจอ)
    components.html(
        html_content,
        height=1000,   # ปรับตัวเลขนี้ได้ตามความสูงหน้าจอที่ต้องการ
        scrolling=False,
    )
